<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

class SportsDB_Admin_Menu {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
    }

    /**
     * Adiciona o menu principal e abas administrativas ao painel do WordPress.
     */
    public static function add_admin_menu() {
        add_menu_page(
            __( 'Configurações do SportsDB', 'sportsdb-plugin' ),
            __( 'SportsDB', 'sportsdb-plugin' ),
            'manage_options',
            'sportsdb-settings',
            array( __CLASS__, 'render_settings_page' ),
            'dashicons-admin-generic'
        );

        add_submenu_page(
            'sportsdb-settings',
            __( 'Shortcodes', 'sportsdb-plugin' ),
            __( 'Shortcodes', 'sportsdb-plugin' ),
            'manage_options',
            'sportsdb-shortcodes',
            array( 'SportsDB_Shortcodes_List', 'render_shortcodes_page' )
        );

        add_submenu_page(
            'sportsdb-settings',
            __( 'Times', 'sportsdb-plugin' ),
            __( 'Times', 'sportsdb-plugin' ),
            'manage_options',
            'sportsdb-teams-crud',
            array( 'SportsDB_Crud', 'render_teams_crud_page' )
        );

        add_submenu_page(
            'sportsdb-settings',
            __( 'Campeonatos', 'sportsdb-plugin' ),
            __( 'Campeonatos', 'sportsdb-plugin' ),
            'manage_options',
            'sportsdb-championships-crud',
            array( 'SportsDB_Crud', 'render_championships_crud_page' )
        );
    }

    /**
     * Registra as configurações gerais.
     */
    public static function register_settings() {
        // Configurações gerais
        register_setting( 'sportsdb_general_settings', 'sportsdb_api_key' );
        register_setting( 'sportsdb_general_settings', 'sportsdb_cache_expiration' );
    }

    /**
     * Renderiza a página principal de configurações.
     */
    public static function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'Configurações do SportsDB', 'sportsdb-plugin' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'sportsdb_general_settings' );
                do_settings_sections( 'sportsdb_general_settings' );
                ?>
                <table class="form-table">
                    <tr>
                        <th><label for="sportsdb_api_key"><?php _e( 'Chave da API', 'sportsdb-plugin' ); ?></label></th>
                        <td><input type="text" id="sportsdb_api_key" name="sportsdb_api_key" value="<?php echo esc_attr( get_option( 'sportsdb_api_key', '' ) ); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="sportsdb_cache_expiration"><?php _e( 'Expiração do Cache (em horas)', 'sportsdb-plugin' ); ?></label></th>
                        <td><input type="number" id="sportsdb_cache_expiration" name="sportsdb_cache_expiration" value="<?php echo esc_attr( get_option( 'sportsdb_cache_expiration', 12 ) ); ?>" class="small-text"></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}

SportsDB_Admin_Menu::init();