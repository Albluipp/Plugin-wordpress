<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

class SportsDB_Style_Handler {
    public static function init() {
        add_action( 'wp_head', array( __CLASS__, 'inject_custom_css' ) );
    }

    /**
     * Injeta o CSS personalizado no cabeçalho do site.
     */
    public static function inject_custom_css() {
        $custom_css = get_option( 'sportsdb_custom_css', '' );

        if ( ! empty( $custom_css ) ) {
            echo '<style type="text/css" id="sportsdb-custom-css">' . esc_html( $custom_css ) . '</style>';
        }
    }
}

SportsDB_Style_Handler::init();