<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

class SportsDB_Database_Handler {
    /**
     * Remove dados antigos do cache com base no tempo de expiração configurado.
     */
    public static function clear_expired_cache() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'sportsdb_results';
        $expiration_hours = get_option( 'sportsdb_cache_expiration', 12 ); // Tempo de expiração padrão: 12 horas
        $expiration_time = time() - ( $expiration_hours * HOUR_IN_SECONDS );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $table_name WHERE updated_at < %s",
                date( 'Y-m-d H:i:s', $expiration_time )
            )
        );
    }

    /**
     * Salva os dados de um time no banco de dados.
     *
     * @param array $team Dados do time.
     */
    public static function save_team_data( $team ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'sportsdb_teams';

        $wpdb->replace(
            $table_name,
            array(
                'team_id'       => $team['idTeam'],
                'team_name'     => $team['strTeam'],
                'team_badge'    => $team['strTeamBadge'],
                'updated_at'    => current_time( 'mysql', 1 ),
            ),
            array( '%d', '%s', '%s', '%s' )
        );
    }

    /**
     * Salva os dados de um jogador no banco de dados.
     *
     * @param array $player Dados do jogador.
     */
    public static function save_player_data( $player ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'sportsdb_players';

        $wpdb->replace(
            $table_name,
            array(
                'player_id'     => $player['idPlayer'],
                'player_name'   => $player['strPlayer'],
                'player_thumb'  => $player['strThumb'],
                'updated_at'    => current_time( 'mysql', 1 ),
            ),
            array( '%d', '%s', '%s', '%s' )
        );
    }
}