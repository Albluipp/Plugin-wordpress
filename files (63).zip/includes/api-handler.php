<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

class SportsDB_API_Handler {
    private static $api_base_url = "https://www.thesportsdb.com/api/v1/json/";

    public static function get_data( $endpoint, $params = array() ) {
        $api_key = get_option( 'sportsdb_api_key', '' );
        if ( empty( $api_key ) ) {
            return array( 'error' => 'A chave da API não está configurada.' );
        }

        $url = self::$api_base_url . $api_key . '/' . $endpoint . '?' . http_build_query( $params );

        $response = wp_remote_get( $url );
        if ( is_wp_error( $response ) ) {
            return array( 'error' => $response->get_error_message() );
        }

        $body = wp_remote_retrieve_body( $response );
        return json_decode( $body, true );
    }
}