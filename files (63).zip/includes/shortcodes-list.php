<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

/**
 * Lista de shortcodes disponíveis no plugin SportsDB.
 */
class SportsDB_Shortcodes_List {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_shortcodes_page' ) );
    }

    /**
     * Adiciona uma página para listar os shortcodes.
     */
    public static function add_shortcodes_page() {
        add_submenu_page(
            'sportsdb-settings',
            __( 'Shortcodes Disponíveis', 'sportsdb-plugin' ),
            __( 'Shortcodes', 'sportsdb-plugin' ),
            'manage_options',
            'sportsdb-shortcodes',
            array( __CLASS__, 'render_shortcodes_page' )
        );
    }

    /**
     * Renderiza a página com a lista de shortcodes.
     */
    public static function render_shortcodes_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'Shortcodes Disponíveis', 'sportsdb-plugin' ); ?></h1>
            <table class="widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e( 'Shortcode', 'sportsdb-plugin' ); ?></th>
                        <th><?php _e( 'Descrição', 'sportsdb-plugin' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>[sportsdb_team id="1234"]</code></td>
                        <td><?php _e( 'Exibe informações de um time específico pelo ID.', 'sportsdb-plugin' ); ?></td>
                    </tr>
                    <tr>
                        <td><code>[sportsdb_championship id="5678"]</code></td>
                        <td><?php _e( 'Exibe informações de um campeonato específico pelo ID.', 'sportsdb-plugin' ); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
    }
}

SportsDB_Shortcodes_List::init();