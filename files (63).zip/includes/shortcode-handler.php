<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SportsDB_Shortcodes {
    public static function init() {
        add_shortcode( 'sportsdb_team', array( __CLASS__, 'render_team' ) );
        add_shortcode( 'sportsdb_championship', array( __CLASS__, 'render_championship' ) );
    }

    /**
     * Renderiza informações de um time.
     */
    public static function render_team( $atts ) {
        $atts = shortcode_atts( array( 'id' => '' ), $atts );
        if ( empty( $atts['id'] ) ) {
            return __( 'Por favor, forneça um ID de time.', 'sportsdb-plugin' );
        }

        $data = SportsDB_API_Handler::get_data( 'lookupteam.php', array( 'id' => $atts['id'] ) );
        if ( isset( $data['teams'][0] ) ) {
            $team = $data['teams'][0];
            return '<h2>' . esc_html( $team['strTeam'] ) . '</h2><img src="' . esc_url( $team['strTeamBadge'] ) . '" alt="' . esc_attr( $team['strTeam'] ) . '">';
        }

        return __( 'Nenhuma informação encontrada para este time.', 'sportsdb-plugin' );
    }

    /**
     * Renderiza informações de um campeonato.
     */
    public static function render_championship( $atts ) {
        $atts = shortcode_atts( array( 'id' => '' ), $atts );
        if ( empty( $atts['id'] ) ) {
            return __( 'Por favor, forneça um ID de campeonato.', 'sportsdb-plugin' );
        }

        $data = SportsDB_API_Handler::get_data( 'lookupleague.php', array( 'id' => $atts['id'] ) );
        if ( isset( $data['leagues'][0] ) ) {
            $league = $data['leagues'][0];
            return '<h2>' . esc_html( $league['strLeague'] ) . '</h2><p>' . esc_html( $league['strDescriptionEN'] ) . '</p>';
        }

        return __( 'Nenhuma informação encontrada para este campeonato.', 'sportsdb-plugin' );
    }
}

SportsDB_Shortcodes::init();