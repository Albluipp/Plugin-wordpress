<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

class SportsDB_Webhook_Handler {
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_webhook_endpoint' ) );
    }

    /**
     * Registra o endpoint para receber webhooks.
     */
    public static function register_webhook_endpoint() {
        register_rest_route(
            'sportsdb/v1',
            '/webhook',
            array(
                'methods'  => WP_REST_Server::CREATABLE,
                'callback' => array( __CLASS__, 'handle_webhook' ),
                'permission_callback' => '__return_true', // Permitir acesso público
            )
        );
    }

    /**
     * Manipula os dados enviados pelo webhook.
     *
     * @param WP_REST_Request $request Dados da requisição.
     * @return WP_REST_Response
     */
    public static function handle_webhook( WP_REST_Request $request ) {
        $body = $request->get_json_params();

        if ( empty( $body ) || ! isset( $body['event'] ) || ! isset( $body['data'] ) ) {
            return new WP_REST_Response(
                array( 'message' => __( 'Dados inválidos recebidos.', 'sportsdb-plugin' ) ),
                400
            );
        }

        $event = $body['event'];
        $data  = $body['data'];

        switch ( $event ) {
            case 'team_updated':
                self::update_team_data( $data );
                break;

            case 'player_updated':
                self::update_player_data( $data );
                break;

            default:
                return new WP_REST_Response(
                    array( 'message' => __( 'Evento desconhecido.', 'sportsdb-plugin' ) ),
                    400
                );
        }

        return new WP_REST_Response(
            array( 'message' => __( 'Webhook processado com sucesso.', 'sportsdb-plugin' ) ),
            200
        );
    }

    /**
     * Atualiza os dados de um time no banco de dados.
     *
     * @param array $data Dados do time.
     */
    private static function update_team_data( $data ) {
        // Atualize o banco de dados ou cache com os dados do time.
        SportsDB_Database_Handler::save_team_data( $data );
    }

    /**
     * Atualiza os dados de um jogador no banco de dados.
     *
     * @param array $data Dados do jogador.
     */
    private static function update_player_data( $data ) {
        // Atualize o banco de dados ou cache com os dados do jogador.
        SportsDB_Database_Handler::save_player_data( $data );
    }
}

SportsDB_Webhook_Handler::init();