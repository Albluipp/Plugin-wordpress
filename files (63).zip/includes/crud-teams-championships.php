<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

/**
 * Classe para gerenciar CRUD de times e campeonatos no SportsDB.
 */
class SportsDB_Crud {
    /**
     * Inicializa os hooks necessários.
     */
    public static function init() {
        // Adiciona páginas ao menu administrativo
        add_action( 'admin_menu', array( __CLASS__, 'add_crud_pages' ) );
    }

    /**
     * Adiciona páginas de CRUD ao menu administrativo.
     */
    public static function add_crud_pages() {
        add_menu_page(
            __( 'SportsDB', 'sportsdb-plugin' ), // Título da página
            __( 'SportsDB', 'sportsdb-plugin' ), // Nome no menu
            'manage_options', // Capacidade necessária
            'sportsdb-main-menu', // Slug do menu
            array( __CLASS__, 'render_main_page' ), // Função de callback
            'dashicons-admin-generic', // Ícone do menu
            50 // Posição no menu
        );

        add_submenu_page(
            'sportsdb-main-menu', // Slug do menu principal
            __( 'Gerenciar Times', 'sportsdb-plugin' ), // Título da página
            __( 'Times', 'sportsdb-plugin' ), // Nome no submenu
            'manage_options', // Capacidade necessária
            'sportsdb-teams-crud', // Slug do submenu
            array( __CLASS__, 'render_teams_page' ) // Função de callback
        );

        add_submenu_page(
            'sportsdb-main-menu', // Slug do menu principal
            __( 'Gerenciar Campeonatos', 'sportsdb-plugin' ), // Título da página
            __( 'Campeonatos', 'sportsdb-plugin' ), // Nome no submenu
            'manage_options', // Capacidade necessária
            'sportsdb-championships-crud', // Slug do submenu
            array( __CLASS__, 'render_championships_page' ) // Função de callback
        );
    }

    /**
     * Renderiza a página principal do plugin.
     */
    public static function render_main_page() {
        echo '<div class="wrap">';
        echo '<h1>' . __( 'Bem-vindo ao SportsDB Plugin', 'sportsdb-plugin' ) . '</h1>';
        echo '<p>' . __( 'Use o menu à esquerda para gerenciar times e campeonatos.', 'sportsdb-plugin' ) . '</p>';
        echo '</div>';
    }

    /**
     * Renderiza a página de gerenciamento de times.
     */
    public static function render_teams_page() {
        echo '<div class="wrap">';
        echo '<h1>' . __( 'Gerenciar Times', 'sportsdb-plugin' ) . '</h1>';
        echo '<form method="post" action="admin-post.php">';
        echo '<input type="hidden" name="action" value="sportsdb_save_team">';
        wp_nonce_field( 'sportsdb_save_team_action', 'sportsdb_nonce' );
        echo '<p><label>' . __( 'Nome do Time:', 'sportsdb-plugin' ) . '</label><br>';
        echo '<input type="text" name="team_name" required></p>';
        echo '<p><label>' . __( 'ID do Time:', 'sportsdb-plugin' ) . '</label><br>';
        echo '<input type="text" name="team_id" required></p>';
        echo '<p><input type="submit" value="' . __( 'Salvar Time', 'sportsdb-plugin' ) . '" class="button button-primary"></p>';
        echo '</form>';
        echo '</div>';
    }

    /**
     * Renderiza a página de gerenciamento de campeonatos.
     */
    public static function render_championships_page() {
        echo '<div class="wrap">';
        echo '<h1>' . __( 'Gerenciar Campeonatos', 'sportsdb-plugin' ) . '</h1>';
        echo '<form method="post" action="admin-post.php">';
        echo '<input type="hidden" name="action" value="sportsdb_save_championship">';
        wp_nonce_field( 'sportsdb_save_championship_action', 'sportsdb_nonce' );
        echo '<p><label>' . __( 'Nome do Campeonato:', 'sportsdb-plugin' ) . '</label><br>';
        echo '<input type="text" name="championship_name" required></p>';
        echo '<p><label>' . __( 'ID do Campeonato:', 'sportsdb-plugin' ) . '</label><br>';
        echo '<input type="text" name="championship_id" required></p>';
        echo '<p><input type="submit" value="' . __( 'Salvar Campeonato', 'sportsdb-plugin' ) . '" class="button button-primary"></p>';
        echo '</form>';
        echo '</div>';
    }
}