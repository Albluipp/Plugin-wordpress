<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SportsDB_Cron_Jobs {
    public static function init() {
        add_action( 'sportsdb_clear_cache_event', array( __CLASS__, 'clear_cache' ) );
        register_activation_hook( __FILE__, array( __CLASS__, 'schedule_cache_clear_event' ) );
        register_deactivation_hook( __FILE__, array( __CLASS__, 'unschedule_cache_clear_event' ) );
    }

    public static function schedule_cache_clear_event() {
        if ( ! wp_next_scheduled( 'sportsdb_clear_cache_event' ) ) {
            wp_schedule_event( time(), 'hourly', 'sportsdb_clear_cache_event' );
        }
    }

    public static function unschedule_cache_clear_event() {
        $timestamp = wp_next_scheduled( 'sportsdb_clear_cache_event' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'sportsdb_clear_cache_event' );
        }
    }

    public static function clear_cache() {
        SportsDB_Database_Handler::clear_expired_cache();
    }
}

SportsDB_Cron_Jobs::init();