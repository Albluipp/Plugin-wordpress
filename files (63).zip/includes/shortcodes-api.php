/**
 * Shortcode para exibir estatísticas de partidas.
 * Uso: [sportsdb_match_stats id="602288"]
 */
public static function match_stats_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'id' => ''
    ), $atts );

    if ( empty( $atts['id'] ) ) {
        return __( 'Por favor, forneça o ID da partida.', 'sportsdb-plugin' );
    }

    $response = self::api_request( 'lookupeventstats.php', array( 'id' => $atts['id'] ) );

    if ( isset( $response->eventstats ) ) {
        $output = '<div class="sportsdb-match-stats">';
        foreach ( $response->eventstats as $stat ) {
            $output .= sprintf(
                '<p><strong>%s:</strong> %s</p>',
                esc_html( $stat->strStat ),
                esc_html( $stat->intHome ) . ' - ' . esc_html( $stat->intAway )
            );
        }
        $output .= '</div>';
        return $output;
    }

    return __( 'Estatísticas da partida não encontradas.', 'sportsdb-plugin' );
}