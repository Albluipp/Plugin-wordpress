# SportsDB Plugin

O **SportsDB Plugin** é um plugin para WordPress que utiliza a [API TheSportsDB](https://www.thesportsdb.com/) para exibir informações esportivas.

## Funcionalidades

- Exibição de classificações de ligas.
- Detalhes de times e jogadores.
- Personalização de estilos.
- Suporte a cache com expiração automática.
- Sincronização automática via webhooks.

## Instalação

1. Faça o upload do diretório `sportsdb-plugin` para a pasta `wp-content/plugins/`.
2. Ative o plugin no menu "Plugins" do WordPress.
3. Configure as opções no painel administrativo.

## Shortcodes

- `[sportsdb_league_standings league_id="1234"]`: Exibe a classificação de uma liga.
- `[sportsdb_team_details team_id="5678"]`: Exibe os detalhes de um time.
- `[sportsdb_player_details player_id="91011"]`: Exibe os detalhes de um jogador.