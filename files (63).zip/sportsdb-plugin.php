<?php
/*
Plugin Name: SportsDB Plugin
Description: Um plugin para gerenciar informações esportivas e exibir dados da API TheSportsDB.
Version: 1.2
Author: Albluipp
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Evita acesso direto.
}

// Inclui o arquivo CRUD para times e campeonatos
require_once plugin_dir_path( __FILE__ ) . 'includes/crud-teams-championships.php';

// Inicializa as funcionalidades do plugin
add_action( 'plugins_loaded', function() {
    if ( class_exists( 'SportsDB_Crud' ) ) {
        SportsDB_Crud::init();
    } else {
        error_log( 'Erro: A classe SportsDB_Crud não foi encontrada!' );
    }
});